package com.techm.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.techm.entity.EmployeeEntity;
import com.techm.repo.EmployeeRepo;
@Service
public class EmployeeService {
	@Autowired
	private EmployeeRepo empRepo; 
	
	public Object setEmployeeDetails(EmployeeEntity empEntity) {
		//System.out.println("kfnd;fn;psds;dlrlsd;i;dsl;tfinsd;nl;");
		empRepo.save(empEntity);
		return empEntity;
	}
}
