package com.techm.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;
@Entity
@Data
@Setter
@Getter
@Table(name ="EMPLOYEE_DETAILS")
public class EmployeeEntity {		
		@GeneratedValue(strategy = GenerationType.AUTO)
		@Column(name = "EMPID",nullable = false)
		@Id
		private Long empId;
		@Column(name = "EMPNAME")
		private String empName;
		@Column(name = "EMP_Type")
		private String empType;	
		@Column(name = "DETAILS")
		private String details;
}
